import type { CmuxTransport, CmuxTransportFactory } from "./cmux.js";
import type { ExecFn } from "./tmux.js";

/** Shell-quote a string using single quotes (POSIX-safe). */
function shellQuote(s: string): string {
  return "'" + s.replace(/'/g, "'\"'\"'") + "'";
}

/**
 * Subclass of Error carrying a stable `code` discriminator and (optional)
 * `method` so the broader adapter / route layer can distinguish surface-level
 * unavailability from request execution failures while staying inside the
 * adapter-only patch boundary. The `code: "unavailable"` vocabulary mirrors
 * the existing CmuxAdapter result discriminator (see `adapters/cmux.ts`).
 */
class CmuxSurfaceError extends Error {
  readonly code: string;
  readonly method: string;

  constructor(method: string, message: string) {
    super(message);
    this.code = "unavailable";
    this.method = method;
    this.name = "CmuxSurfaceError";
  }
}

/**
 * Parse the subcommand block of `cmux --help` into a Set of available
 * top-level command names. cmux's help format puts each command on a
 * line indented with two spaces, e.g.:
 *
 *   Commands:
 *     list-panels [--workspace <id|ref>]
 *     focus-panel --panel <id|ref>
 *
 * Lenient: if the help output is unparseable for any reason, the Set is
 * empty and downstream version-adaptive dispatch will treat surfaces as
 * unsupported, which is the honest answer.
 */
function parseCmuxCommands(help: string): Set<string> {
  const commands = new Set<string>();
  for (const rawLine of help.split("\n")) {
    const match = rawLine.match(/^\s{2,}([a-z][a-z0-9-]+)/);
    if (match && match[1]) commands.add(match[1]);
  }
  return commands;
}

interface BuildContext {
  supported: Set<string>;
}

interface BuildResult {
  cmd: string;
  json: boolean;
}

function buildCommand(
  method: string,
  params: Record<string, unknown> | undefined,
  ctx: BuildContext
): BuildResult {
  // --- Stable commands (present on every supported cmux version) ---
  if (method === "capabilities") {
    return { cmd: "cmux capabilities --json", json: true };
  }
  if (method === "workspace.list") {
    if (ctx.supported.has("rpc")) {
      return { cmd: "cmux rpc workspace.list", json: true };
    }
    return { cmd: "cmux list-workspaces --json", json: true };
  }
  if (method === "workspace.current") {
    return { cmd: "cmux current-workspace --json", json: true };
  }

  // --- Version-adaptive: surface listing ---
  // cmux ≥0.63 ships `list-panels`; older cmux exposed `list-surfaces`.
  // Architect direction: prefer the new surface, keep the legacy fallback,
  // never version-pin away newer cmux. Both shapes are normalized to the
  // `{surfaces: [...]}` payload that downstream `CmuxAdapter.listSurfaces`
  // expects (see `adapters/cmux.ts:110-123`).
  if (method === "surface.list") {
    const workspaceArg = params?.workspaceId
      ? ` --workspace ${shellQuote(String(params.workspaceId))}`
      : "";
    if (ctx.supported.has("list-panels")) {
      return { cmd: `cmux list-panels${workspaceArg} --json`, json: true };
    }
    if (ctx.supported.has("list-surfaces")) {
      return { cmd: `cmux list-surfaces${workspaceArg} --json`, json: true };
    }
    throw new CmuxSurfaceError(
      method,
      "cmux does not expose a surface-listing command (neither `list-panels` nor `list-surfaces`)"
    );
  }

  // --- Version-adaptive: agent PID enumeration ---
  // `cmux agent-pids` was removed in 0.63.x with no replacement. Honest
  // detection: refuse loudly if the legacy command is absent rather than
  // calling it and letting cmux emit "Unknown command".
  if (method === "workspace.agentPIDs") {
    if (ctx.supported.has("agent-pids")) {
      return { cmd: "cmux agent-pids --json", json: true };
    }
    throw new CmuxSurfaceError(
      method,
      "cmux does not expose `agent-pids` (removed in cmux 0.63.x; no equivalent surface)"
    );
  }

  // --- Stable parameterized commands ---
  if (method === "surface.create" && params?.workspaceId) {
    return {
      cmd: `cmux new-surface --type ${shellQuote(String(params.type ?? "terminal"))} --workspace ${shellQuote(String(params.workspaceId))} --json`,
      json: true,
    };
  }

  if (method === "surface.focus" && params?.surfaceId) {
    const workspaceArg = params.workspaceId
      ? ` --workspace ${shellQuote(String(params.workspaceId))}`
      : "";
    return {
      cmd: `cmux focus-panel --panel ${shellQuote(String(params.surfaceId))}${workspaceArg}`,
      json: false,
    };
  }

  if (method === "surface.sendText" && params?.surfaceId && params?.text != null) {
    const workspaceArg = params.workspaceId
      ? ` --workspace ${shellQuote(String(params.workspaceId))}`
      : "";
    return {
      cmd: `cmux send --surface ${shellQuote(String(params.surfaceId))}${workspaceArg} ${shellQuote(String(params.text))}`,
      json: false,
    };
  }

  // Slice 24 — generic RPC pass-through for layout methods (splitSurface,
  // createWorkspace, closeWorkspace, listPaneSurfaces; OPR.0.4.7.1 adds
  // equalizeSplits). cmux exposes a
  // `cmux rpc <method> '<json-params>'` subcommand that delegates directly
  // to the daemon RPC. Spike confirmed these methods accept snake_case
  // params (the adapter passes them in already snake_cased). Generic
  // path is cleaner than per-method CLI mapping for methods that have a
  // 1:1 RPC correspondence; reserves the version-adaptive buildCommand
  // branches above for legacy methods that have CLI-only shapes.
  // NOTE: an adapter RPC whose method name is missing from this allowlist
  // throws Unknown cmux method AT RUNTIME ONLY — adapter unit tests ride a
  // fake transport and cannot catch the omission (the OPR.0.4.7.1 equalize
  // miss). Every new adapter RPC needs its cmux-transport exact-command
  // regression test alongside this entry.
  if (
    method === "surface.split" ||
    method === "workspace.create" ||
    method === "workspace.close" ||
    method === "workspace.equalize_splits" ||
    method === "pane.surfaces"
  ) {
    const paramsJson = params ? JSON.stringify(params) : "";
    const cmd = paramsJson
      ? `cmux rpc ${method} ${shellQuote(paramsJson)}`
      : `cmux rpc ${method}`;
    return { cmd, json: true };
  }

  throw new Error(`Unknown cmux method: ${method}`);
}

/**
 * Normalize JSON payloads from version-adaptive commands so downstream
 * consumers see one stable shape regardless of which cmux command actually
 * answered.
 */
function normalizePayload(method: string, raw: unknown): unknown {
  if (method === "workspace.list") {
    if (raw === null || typeof raw !== "object") return raw;
    const obj = raw as Record<string, unknown>;
    if (!Array.isArray(obj.workspaces)) return raw;
    return {
      ...obj,
      workspaces: obj.workspaces
        .map(normalizeWorkspaceRow)
        .filter((workspace): workspace is { id: string; name: string } => workspace !== null),
    };
  }

  if (method !== "surface.list") return raw;
  if (raw === null || typeof raw !== "object") return raw;
  const obj = raw as Record<string, unknown>;
  // OPR.0.3.3.18: cmux 0.64.x renamed the surface identifier - `list-panels`
  // rows carry `ref` with NO `id` (0.63.x rows carried `id`) - AND may key the
  // array as `panels`/`pane_surfaces`. Resolve BOTH the array key AND each
  // row's handle to one stable `{surfaces: [{id,title,type}]}` shape so
  // downstream `CmuxAdapter.listSurfaces` (and the layout service's
  // `result.data[0].id` read) sees a populated `id` regardless of cmux
  // version. This is the SAME presence-based adaptation already applied to
  // `workspace.list` rows (`normalizeWorkspaceRow`) and to the surface-create /
  // split handles (`adapters/cmux.ts`) - one resolution order, both versions,
  // NOT a version-negotiation shim. 0.63.x rows that carry `id` resolve
  // unchanged.
  const rows =
    Array.isArray(obj.surfaces) ? obj.surfaces
    : Array.isArray(obj.panels) ? obj.panels
    : Array.isArray(obj.pane_surfaces) ? obj.pane_surfaces
    : null;
  if (rows === null) return raw;
  const rest: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key === "surfaces" || key === "panels" || key === "pane_surfaces") continue;
    rest[key] = value;
  }
  return {
    ...rest,
    surfaces: rows
      .map(normalizeSurfaceRow)
      .filter((surface): surface is { id: string; title: string; type: string } => surface !== null),
  };
}

function normalizeSurfaceRow(row: unknown): { id: string; title: string; type: string } | null {
  if (row === null || typeof row !== "object") return null;
  const obj = row as Record<string, unknown>;
  // OPR.0.3.3.18: resolve the surface handle from whichever key the installed
  // cmux provides. `ref` is preferred (cmux 0.64.x list-panels) then the
  // snake_case variants, then `id` (cmux 0.63.x) - the same precedence the
  // create/split handle resolution uses in `adapters/cmux.ts` and that
  // `normalizeWorkspaceRow` uses for workspace rows.
  const id =
    typeof obj.ref === "string" && obj.ref.trim()
      ? obj.ref.trim()
      : typeof obj.surface_ref === "string" && obj.surface_ref.trim()
        ? obj.surface_ref.trim()
        : typeof obj.surface_id === "string" && obj.surface_id.trim()
          ? obj.surface_id.trim()
          : typeof obj.id === "string" && obj.id.trim()
            ? obj.id.trim()
            : "";
  if (!id) return null;
  const title = typeof obj.title === "string" ? obj.title : "";
  const type =
    typeof obj.type === "string" && obj.type.trim() ? obj.type : "terminal";
  return { id, title, type };
}

function normalizeWorkspaceRow(row: unknown): { id: string; name: string } | null {
  if (row === null || typeof row !== "object") return null;
  const obj = row as Record<string, unknown>;
  const id =
    typeof obj.ref === "string"
      ? obj.ref
      : typeof obj.workspace_ref === "string"
        ? obj.workspace_ref
        : typeof obj.id === "string"
          ? obj.id
          : typeof obj.workspace_id === "string"
            ? obj.workspace_id
            : "";
  if (!id) return null;
  const name =
    typeof obj.name === "string" && obj.name.trim()
      ? obj.name.trim()
      : typeof obj.title === "string" && obj.title.trim()
        ? obj.title.trim()
        : id;
  return { id, name };
}

/**
 * CLI-based CmuxTransportFactory.
 *
 * At factory time, probes `cmux --help` to discover the live cmux command
 * surface. The probe doubles as a binary-presence check (replaces the older
 * `cmux capabilities --json` verify): a missing cmux binary makes exec throw
 * ENOENT, which the factory propagates to the caller. The probe result is
 * cached on the returned transport instance and consulted on every request
 * to dispatch to the correct command for the installed cmux version.
 */
export function createCmuxCliTransport(exec: ExecFn): CmuxTransportFactory {
  return async (): Promise<CmuxTransport> => {
    const helpOutput = await exec("cmux --help");
    const supported = parseCmuxCommands(helpOutput);

    return {
      request: async (method: string, params?: unknown): Promise<unknown> => {
        const { cmd, json } = buildCommand(
          method,
          params as Record<string, unknown> | undefined,
          { supported }
        );
        const output = await exec(cmd);

        if (json) {
          let parsed: unknown;
          try {
            parsed = JSON.parse(output);
          } catch {
            const legacyFallback = legacyJsonFallback(method, output);
            if (legacyFallback !== null) {
              return legacyFallback;
            }
            throw new Error(
              `Failed to parse JSON from cmux command '${cmd}': ${output.slice(0, 200)}`
            );
          }
          return normalizePayload(method, parsed);
        }

        return {};
      },
      close: () => {
        // CLI-based transport has no persistent connection to close
      },
    };
  };
}

function legacyJsonFallback(method: string, output: string): unknown | null {
  const trimmed = output.trim();
  if (!trimmed) {
    return method === "surface.list" ? { surfaces: [] } : null;
  }

  // cmux 0.61.x can still return a bare handle for some --json commands.
  if (method === "workspace.current") {
    return { workspace_id: trimmed };
  }

  if (method === "surface.create") {
    const summary = trimmed.replace(/^OK\s+/, "");
    const refMatch = summary.match(/(?:^|\s)(surface:[^\s]+)/);
    if (refMatch) {
      return { created_surface_ref: refMatch[1] };
    }
    const firstToken = summary.split(/\s+/)[0];
    if (firstToken) {
      return { created_surface_ref: firstToken };
    }
    return null;
  }

  if (method === "surface.list") {
    const surfaces = parsePlainTextSurfaceRows(trimmed);
    if (surfaces) {
      return { surfaces };
    }
  }

  if (method === "workspace.list") {
    const workspaces = parsePlainTextWorkspaceRows(trimmed);
    if (workspaces) {
      return { workspaces };
    }
  }

  return null;
}

function parsePlainTextWorkspaceRows(output: string): Array<{ id: string; name: string }> | null {
  const workspaces: Array<{ id: string; name: string }> = [];

  for (const rawLine of output.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;

    const rowMatch = line.match(/^(?:\*\s+)?(workspace:[^\s]+)(?:\s+(.*?))?\s*$/);
    if (!rowMatch || !rowMatch[1]) {
      return null;
    }
    const rawName = (rowMatch[2] ?? "").replace(/\s+\[[^\]]+\]\s*$/g, "").trim();
    workspaces.push({
      id: rowMatch[1],
      name: rawName || rowMatch[1],
    });
  }

  return workspaces;
}

function parsePlainTextSurfaceRows(output: string): Array<{ id: string; title: string; type: string }> | null {
  const surfaces: Array<{ id: string; title: string; type: string }> = [];
  const knownSurfaceTypes = new Set(["terminal", "browser", "markdown"]);

  for (const rawLine of output.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;

    const rowMatch = line.match(
      /^(?:\*\s+)?(surface:[^\s]+)\s+([a-z][a-z0-9-]*)(?:\s+\[[^\]]+\])*\s*(?:"([^"]*)")?\s*$/i
    );
    if (!rowMatch || !rowMatch[1] || !rowMatch[2]) {
      return null;
    }
    const type = rowMatch[2].toLowerCase();
    if (!knownSurfaceTypes.has(type)) {
      return null;
    }

    surfaces.push({
      id: rowMatch[1],
      title: rowMatch[3] ?? "",
      type,
    });
  }

  return surfaces;
}
