// Slice 27 — Claude Auto-Compaction Policy form.
//
// Operator-configurable pre-compaction trigger: when a Claude seat's
// context usage crosses `threshold_percent`, the daemon's ContextMonitor
// first sends a fixed-wrapper preparation prompt plus operator-editable
// `pre_compact_instruction`, then dispatches `/compact` via
// SessionTransport on the next eligible observation, optionally with
// `compact_instruction` as slash-command args. The restore phase uses
// `message_inline`, `message_file_path`, and an editable
// `post_restore_audit_instruction` wrapped by daemon-owned trust
// framing.
//
// Opt-in default-off. Inline points at the canonical restore skill; the
// file path points at a user-owned extra-instructions placeholder.

import { useState } from "react";
import type { FormEvent } from "react";
import { SectionHeader } from "../ui/section-header.js";
import { useSettings, useSetSetting } from "../../hooks/useSettings.js";

type FormState = {
  enabled: boolean;
  thresholdPercent: string;
  preCompactInstruction: string;
  compactInstruction: string;
  messageInline: string;
  messageFilePath: string;
  postRestoreAuditInstruction: string;
};

const KEY_ENABLED = "policies.claude_compaction.enabled" as const;
const KEY_THRESHOLD = "policies.claude_compaction.threshold_percent" as const;
const KEY_PRE_COMPACT_INSTRUCTION = "policies.claude_compaction.pre_compact_instruction" as const;
const KEY_COMPACT_INSTRUCTION = "policies.claude_compaction.compact_instruction" as const;
const KEY_INLINE = "policies.claude_compaction.message_inline" as const;
const KEY_FILE_PATH = "policies.claude_compaction.message_file_path" as const;
const KEY_POST_RESTORE_AUDIT = "policies.claude_compaction.post_restore_audit_instruction" as const;

function coerceBoolean(value: unknown, fallback: boolean): boolean {
  if (typeof value === "boolean") return value;
  if (value === "true") return true;
  if (value === "false") return false;
  return fallback;
}

function coerceNumber(value: unknown, fallback: number): number {
  if (typeof value === "number") return value;
  if (typeof value === "string" && value.trim().length > 0) {
    const n = Number(value);
    if (!Number.isNaN(n)) return n;
  }
  return fallback;
}

function coerceString(value: unknown): string {
  if (typeof value === "string") return value;
  if (value === null || value === undefined) return "";
  return String(value);
}

export function ClaudeCompactionPolicyForm() {
  const { data, isLoading, error } = useSettings();
  const setSetting = useSetSetting();

  if (!data) {
    return (
      <section
        data-testid="claude-compaction-policy-form"
        className="border border-outline-variant p-5 bg-surface-lowest/50"
      >
        <SectionHeader tone="muted">Policy</SectionHeader>
        <h2 className="font-headline text-headline-sm font-bold tracking-tight uppercase text-on-surface mt-1">
          Claude Auto-Compaction
        </h2>
        {isLoading && (
          <p className="mt-4 text-sm text-on-surface-variant" data-testid="claude-compaction-policy-loading">
            Loading current settings…
          </p>
        )}
        {error && (
          <p className="mt-4 text-sm text-error" data-testid="claude-compaction-policy-error">
            {error instanceof Error ? error.message : String(error)}
          </p>
        )}
      </section>
    );
  }

  return <PolicyFormBody data={data.settings} setSetting={setSetting} />;
}

interface PolicyFormBodyProps {
  data: Record<string, { value: unknown }>;
  setSetting: ReturnType<typeof useSetSetting>;
}

function PolicyFormBody({ data, setSetting }: PolicyFormBodyProps) {
  const [form, setForm] = useState<FormState>(() => ({
    enabled: coerceBoolean(data[KEY_ENABLED]?.value, false),
    thresholdPercent: String(coerceNumber(data[KEY_THRESHOLD]?.value, 80)),
    preCompactInstruction: coerceString(data[KEY_PRE_COMPACT_INSTRUCTION]?.value),
    compactInstruction: coerceString(data[KEY_COMPACT_INSTRUCTION]?.value),
    messageInline: coerceString(data[KEY_INLINE]?.value),
    messageFilePath: coerceString(data[KEY_FILE_PATH]?.value),
    postRestoreAuditInstruction: coerceString(data[KEY_POST_RESTORE_AUDIT]?.value),
  }));
  const [thresholdError, setThresholdError] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitOk, setSubmitOk] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitOk(false);
    setSubmitError(null);
    const thresholdRaw = form.thresholdPercent.trim();
    const thresholdValue = Number(thresholdRaw);
    if (!/^\d+$/.test(thresholdRaw) || thresholdValue < 1 || thresholdValue > 100) {
      setThresholdError("Threshold must be an integer between 1 and 100.");
      return;
    }
    setThresholdError(null);

    const updates: Array<{ key: Parameters<typeof setSetting.mutateAsync>[0]["key"]; value: string }> = [
      { key: KEY_ENABLED, value: form.enabled ? "true" : "false" },
      { key: KEY_THRESHOLD, value: String(thresholdValue) },
      { key: KEY_PRE_COMPACT_INSTRUCTION, value: form.preCompactInstruction },
      { key: KEY_COMPACT_INSTRUCTION, value: form.compactInstruction },
      { key: KEY_INLINE, value: form.messageInline },
      { key: KEY_FILE_PATH, value: form.messageFilePath },
      { key: KEY_POST_RESTORE_AUDIT, value: form.postRestoreAuditInstruction },
    ];
    try {
      for (const update of updates) {
        await setSetting.mutateAsync(update);
      }
      setSubmitOk(true);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : String(err));
    }
  }

  return (
    <section
      data-testid="claude-compaction-policy-form"
      className="border border-outline-variant p-5 bg-surface-lowest/50"
    >
      <SectionHeader tone="muted">Policy</SectionHeader>
      <h2 className="font-headline text-headline-sm font-bold tracking-tight uppercase text-on-surface mt-1">
        Claude Auto-Compaction
      </h2>
      <p className="mt-2 text-sm text-on-surface-variant max-w-prose">
        When a Claude seat's context usage crosses the configured threshold,
        OpenRig first sends a preparation message, then sends
        <code className="font-mono text-[12px]"> /compact</code> on the next
        eligible observation. After compaction, OpenRig sends one restore prompt
        that points the seat at its restore packet, followed by a read-depth
        audit prompt.
      </p>

      <form
        className="mt-4 flex flex-col gap-5"
        onSubmit={handleSubmit}
        data-testid="claude-compaction-policy-form-element"
      >
        <label className="inline-flex items-center gap-2 text-sm text-on-surface">
          <input
            type="checkbox"
            data-testid="claude-compaction-enabled"
            checked={form.enabled}
            onChange={(e) => setForm((s) => ({ ...s, enabled: e.target.checked }))}
          />
          <span>Enable automatic pre-compaction trigger</span>
        </label>

        <div className="flex flex-col gap-1">
          <label htmlFor="claude-compaction-threshold" className="text-sm font-medium text-on-surface">
            Threshold percentage
          </label>
          <input
            id="claude-compaction-threshold"
            data-testid="claude-compaction-threshold"
            type="text"
            inputMode="numeric"
            pattern="[0-9]*"
            value={form.thresholdPercent}
            onChange={(e) => setForm((s) => ({ ...s, thresholdPercent: e.target.value }))}
            className="border border-outline-variant px-2 py-1 w-32 font-mono text-sm"
            aria-describedby="claude-compaction-threshold-hint"
          />
          <span className="text-xs text-on-surface-variant">
            Preparation starts when context usage is at-or-above this percentage (1–100).
          </span>
          {thresholdError && (
            <span className="text-xs text-error" data-testid="claude-compaction-threshold-error">
              {thresholdError}
            </span>
          )}
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="claude-compaction-pre-compact-instruction" className="text-sm font-medium text-on-surface">
            Pre-compaction prep message
          </label>
          <textarea
            id="claude-compaction-pre-compact-instruction"
            data-testid="claude-compaction-pre-compact-instruction"
            rows={4}
            value={form.preCompactInstruction}
            onChange={(e) => setForm((s) => ({ ...s, preCompactInstruction: e.target.value }))}
            placeholder="Read the claude-compaction-restore skill and prepare for compaction."
            className="border border-outline-variant px-2 py-1 font-mono text-sm"
          />
          <span className="text-xs text-on-surface-variant">
            OpenRig wraps this with the current context usage, threshold, and
            operator-authorized user-channel framing.
          </span>
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="claude-compaction-compact-instruction" className="text-sm font-medium text-on-surface">
            Compaction instruction
          </label>
          <textarea
            id="claude-compaction-compact-instruction"
            data-testid="claude-compaction-compact-instruction"
            rows={3}
            value={form.compactInstruction}
            onChange={(e) => setForm((s) => ({ ...s, compactInstruction: e.target.value }))}
            placeholder="Optional. Sent as /compact <instruction> when OpenRig triggers compaction."
            className="border border-outline-variant px-2 py-1 font-mono text-sm"
          />
          <span className="text-xs text-on-surface-variant">
            Optional advanced override. Leave blank to rely on Claude's native
            compaction summary; OpenRig still appends a trust-channel note.
          </span>
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="claude-compaction-inline" className="text-sm font-medium text-on-surface">
            Post-compaction restore instruction (inline)
          </label>
          <textarea
            id="claude-compaction-inline"
            data-testid="claude-compaction-message-inline"
            rows={4}
            value={form.messageInline}
            onChange={(e) => setForm((s) => ({ ...s, messageInline: e.target.value }))}
            placeholder="Optional override. Leave blank to use the instruction file path below."
            className="border border-outline-variant px-2 py-1 font-mono text-sm"
          />
          <span className="text-xs text-on-surface-variant">
            Default asks Claude to read the claude-compaction-restore skill.
            OpenRig wraps this with marker, transcript, and current-task
            framing.
          </span>
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="claude-compaction-file" className="text-sm font-medium text-on-surface">
            Post-compaction restore instruction (file path)
          </label>
          <input
            id="claude-compaction-file"
            data-testid="claude-compaction-message-file-path"
            type="text"
            value={form.messageFilePath}
            onChange={(e) => setForm((s) => ({ ...s, messageFilePath: e.target.value }))}
            placeholder="Path read at hook-fire time for extra restore instructions."
            className="border border-outline-variant px-2 py-1 font-mono text-sm"
          />
          <span className="text-xs text-on-surface-variant">
            Default points at a user-owned placeholder file. Put
            mission-specific reading lists or extra restore notes there
            without changing the canonical skill.
          </span>
        </div>

        <div className="flex flex-col gap-1">
          <label htmlFor="claude-compaction-post-restore-audit" className="text-sm font-medium text-on-surface">
            Post-restore audit message
          </label>
          <textarea
            id="claude-compaction-post-restore-audit"
            data-testid="claude-compaction-post-restore-audit-instruction"
            rows={4}
            value={form.postRestoreAuditInstruction}
            onChange={(e) => setForm((s) => ({ ...s, postRestoreAuditInstruction: e.target.value }))}
            placeholder="Read the claude-compaction-restore skill and audit restore read depth."
            className="border border-outline-variant px-2 py-1 font-mono text-sm"
          />
          <span className="text-xs text-on-surface-variant">
            OpenRig wraps this with the required FULL/PARTIAL/NOT_READ table
            and no-token-conservation language.
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="submit"
            data-testid="claude-compaction-policy-submit"
            disabled={setSetting.isPending}
            className="border border-outline px-4 py-2 bg-inverse-surface text-background font-medium text-sm disabled:opacity-60"
          >
            {setSetting.isPending ? "Saving…" : "Save policy"}
          </button>
          {submitOk && (
            <span className="text-sm text-success" data-testid="claude-compaction-policy-saved">
              Saved.
            </span>
          )}
          {submitError && (
            <span className="text-sm text-error" data-testid="claude-compaction-policy-submit-error">
              {submitError}
            </span>
          )}
        </div>
      </form>
    </section>
  );
}
