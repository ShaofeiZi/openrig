// Slice 24 — launchRigCmux.
//
// Promise helper that POSTs to /api/rigs/:rigId/cmux/launch (the new
// daemon endpoint shipped in slice 24 Checkpoint C). Returns the
// workspaces array from the daemon's response on success; throws an
// Error carrying the daemon's honest 3-part message on 4xx/5xx.
//
// Distinct from useCmuxLaunch.ts which targets a single node's
// open-or-focus endpoint POST /api/rigs/:rigId/nodes/:logicalId/open-cmux.

export interface RigCmuxLaunchInput {
  rigId: string;
}

export interface CmuxLaunchedWorkspace {
  name: string;
  agents: string[];
  blanks: number;
}

export interface MissingSeat {
  logicalId: string;
  reason: string;
}

export interface RigCmuxLaunchSuccess {
  ok: true;
  workspaces: CmuxLaunchedWorkspace[];
  missing?: MissingSeat[];
}

interface RigCmuxLaunchErrorBody {
  error: string;
  message: string;
  partial?: CmuxLaunchedWorkspace[];
}

export async function launchRigCmux({ rigId }: RigCmuxLaunchInput): Promise<RigCmuxLaunchSuccess> {
  const res = await fetch(`/api/rigs/${encodeURIComponent(rigId)}/cmux/launch`, {
    method: "POST",
  });
  if (!res.ok) {
    let body: RigCmuxLaunchErrorBody | null = null;
    try {
      body = (await res.json()) as RigCmuxLaunchErrorBody;
    } catch {
      // fall through
    }
    const message = body?.message ?? body?.error ?? `HTTP ${res.status}`;
    throw new Error(message);
  }
  return (await res.json()) as RigCmuxLaunchSuccess;
}
